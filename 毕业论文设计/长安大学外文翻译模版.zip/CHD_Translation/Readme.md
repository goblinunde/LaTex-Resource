此模版为长安大学本科生毕业设计（论文）外文翻译模板，非官方模版，请个人参考使用。

主文件为 example.tex
完整编译: xelatex -> bibtex -> xelatex -> xelatex
