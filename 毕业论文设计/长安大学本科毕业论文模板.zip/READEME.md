# 长安大学本科毕业论文模板

本模板适用于长安大学本科毕业论文。

## 使用说明

将`CHDtheisis.cls`文件、`chdname.otf`文件、`logo.pdf`文件与主文件放在同一个目录下，在主文件中使用`\documentclass`命令导入`CHDthesis`文档类，接下来正常写作。

本模板需使用XeLaTeX编译，使用BibTeX进行参考文献管理，若有参考文献，则编译方式为：
- xelatex
- bibtex
- xelatex
- xelatex

若无参考文献，则编译方式为：
- xelatex
- xelatex


具体使用说明参见`main.pdf`