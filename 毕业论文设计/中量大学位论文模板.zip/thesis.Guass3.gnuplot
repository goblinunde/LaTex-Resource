set table "thesis.Guass3.table"; set format "%.5f"
set samples 25; plot [x=-1.15:3.15] 1/(sqrt(2*pi)*0.75)*exp(-(x-1)**2/(2*0.75*0.75))
