set table "thesis.Guass4.table"; set format "%.5f"
set samples 25; plot [x=-0.25:4.25] 1/(sqrt(2*pi)*0.75)*exp(-(x-2)**2/(2*0.75*0.75))
