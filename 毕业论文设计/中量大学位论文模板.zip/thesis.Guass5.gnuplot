set table "thesis.Guass5.table"; set format "%.5f"
set samples 25; plot [x=-1.25:3.25] 1/(sqrt(2*pi)*0.75)*exp(-(x-1)**2/(2*0.75*0.75))
