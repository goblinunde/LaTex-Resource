set table "thesis.Guass2.table"; set format "%.5f"
set samples 25; plot [x=-1.5:3.5] 1/(sqrt(2*pi)*1.25)*exp(-(x-1)**2/(2*1.25*1.25))
