@echo off
del *.aux *.lo? *.toc *.ind *.inx *.gls *.glo *.ist *.idx *.ilg *.out *.bak *.bbl *.brf *.blg *.dvi *.ps data\*.aux
xelatex thesis
bibtex thesis
MakeIndex thesis
xelatex thesis
xelatex thesis
xelatex thesis

call  clear
start thesis.pdf
