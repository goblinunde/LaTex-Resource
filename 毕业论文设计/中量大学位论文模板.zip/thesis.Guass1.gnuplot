set table "thesis.Guass1.table"; set format "%.5f"
set samples 25; plot [x=-1.35:3.35] 1/(sqrt(2*pi))*exp(-(x-1)**2/2)
